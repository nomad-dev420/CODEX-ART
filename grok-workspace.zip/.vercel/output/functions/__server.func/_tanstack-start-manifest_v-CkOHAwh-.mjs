//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkOHAwh-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D4LfOUxw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D4LfOUxw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-9jW0sAqU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
