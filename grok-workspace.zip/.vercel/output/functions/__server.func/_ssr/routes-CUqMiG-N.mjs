import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Hash, c as Copy, i as Image$1, l as Contrast, n as Upload, o as FileCode2, s as Download, t as Wand, u as Binary } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Viewport, n as Scrollbar, r as Thumb, t as Root } from "../_libs/radix-ui__react-scroll-area.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CUqMiG-N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PALETTES = [
	{
		id: "binary",
		label: "Binary",
		chars: "10",
		hint: "Ones and zeros"
	},
	{
		id: "hash",
		label: "Hash",
		chars: " *#",
		hint: "Space, star, hash"
	},
	{
		id: "marks",
		label: "Marks",
		chars: " #",
		hint: "Silhouette in hashes"
	},
	{
		id: "stars",
		label: "Stars",
		chars: " *",
		hint: "Silhouette in stars"
	},
	{
		id: "blocks",
		label: "Blocks",
		chars: " ░▒▓█",
		hint: "Shaded box drawing"
	},
	{
		id: "classic",
		label: "Classic",
		chars: " .:-=+*#%@",
		hint: "Traditional ASCII"
	}
];
var CHAR_ASPECT = .55;
function luma(r, g, b, a) {
	if (a < 8) return 0;
	return .2126 * r + .7152 * g + .0722 * b;
}
function rowsFor(cols, width, height) {
	const rows = Math.round(cols * (height / Math.max(width, 1)) * CHAR_ASPECT);
	return Math.max(8, Math.min(64, rows));
}
function rasterize(source, sourceWidth, sourceHeight, cols) {
	const rows = rowsFor(cols, sourceWidth, sourceHeight);
	const canvas = document.createElement("canvas");
	canvas.width = cols;
	canvas.height = rows;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Canvas is unavailable");
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "high";
	ctx.fillStyle = "#000";
	ctx.fillRect(0, 0, cols, rows);
	ctx.drawImage(source, 0, 0, cols, rows);
	return ctx.getImageData(0, 0, cols, rows);
}
function imageDataToAscii(image, options) {
	const { width, height, data } = image;
	const chars = Array.from(options.charset);
	if (chars.length < 2) throw new Error("Charset needs at least two characters");
	const n = chars.length - 1;
	const gray = new Float32Array(width * height);
	for (let i = 0; i < width * height; i++) {
		const o = i * 4;
		let v = luma(data[o], data[o + 1], data[o + 2], data[o + 3]);
		if (options.invert) v = 255 - v;
		gray[i] = v;
	}
	const lines = [];
	for (let y = 0; y < height; y++) {
		let line = "";
		for (let x = 0; x < width; x++) {
			const i = y * width + x;
			let v = gray[i];
			if (v < 0) v = 0;
			if (v > 255) v = 255;
			const idx = Math.round(v / 255 * n);
			line += chars[idx];
			if (options.dither) {
				const quantized = idx / n * 255;
				const err = v - quantized;
				if (x + 1 < width) gray[i + 1] += err * 7 / 16;
				if (y + 1 < height) {
					if (x > 0) gray[i + width - 1] += err * 3 / 16;
					gray[i + width] += err * 5 / 16;
					if (x + 1 < width) gray[i + width + 1] += err * 1 / 16;
				}
			}
		}
		lines.push(line);
	}
	return lines.join("\n");
}
function padAscii(ascii, cols, rows, fill = " ") {
	const src = ascii.replace(/\r/g, "").split("\n");
	const out = [];
	for (let y = 0; y < rows; y++) {
		const raw = src[y] ?? "";
		const clipped = Array.from(raw).slice(0, cols);
		while (clipped.length < cols) clipped.push(fill);
		out.push(clipped.join(""));
	}
	return out.join("\n");
}
function measureAscii(ascii) {
	const lines = ascii.replace(/\r/g, "").split("\n").filter((l, i, a) => !(i === a.length - 1 && l === ""));
	return {
		cols: lines.reduce((m, l) => Math.max(m, Array.from(l).length), 0),
		rows: lines.length,
		lines
	};
}
function sanitizeCharset(chars) {
	const forbidden = /* @__PURE__ */ new Set([
		"\"",
		"'",
		"\\",
		"<",
		">",
		"&",
		"`"
	]);
	const seen = /* @__PURE__ */ new Set();
	let out = "";
	for (const ch of Array.from(chars)) {
		if (forbidden.has(ch) || seen.has(ch)) continue;
		if (ch.charCodeAt(0) < 32) continue;
		seen.add(ch);
		out += ch;
	}
	return out.length >= 2 ? out : "10";
}
function compressImage(source, width, height, maxEdge = 512, quality = .72) {
	const scale = Math.min(1, maxEdge / Math.max(width, height));
	const w = Math.max(32, Math.round(width * scale));
	const h = Math.max(32, Math.round(height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas is unavailable");
	ctx.fillStyle = "#000";
	ctx.fillRect(0, 0, w, h);
	ctx.drawImage(source, 0, 0, w, h);
	return canvas.toDataURL("image/jpeg", quality);
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that image"));
		img.src = src;
	});
}
var INKS = [
	{
		id: "bone",
		label: "Bone",
		bg: "#0c0c0d",
		fg: "#e8e4d8"
	},
	{
		id: "steel",
		label: "Steel",
		bg: "#0e1216",
		fg: "#c5d0d8"
	},
	{
		id: "sage",
		label: "Sage",
		bg: "#0c100e",
		fg: "#c5d4c8"
	},
	{
		id: "print",
		label: "Print",
		bg: "#ece8de",
		fg: "#1a1916"
	}
];
function inkById(id) {
	return INKS.find((i) => i.id === id) ?? INKS[0];
}
function sanitizeIdentifier(raw, fallback) {
	return raw.replace(/[^A-Za-z0-9_]/g, "").replace(/^[^A-Za-z_]+/, "").slice(0, 24) || fallback;
}
function sanitizeSymbol(raw) {
	return raw.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "GLYPH";
}
function escapeXml(s) {
	const amp = "&";
	return s.replaceAll("&", `${amp}amp;`).replaceAll("<", `${amp}lt;`).replaceAll(">", `${amp}gt;`).replaceAll("\"", `${amp}quot;`);
}
function escapeSolidity(s) {
	return s.replaceAll("\\", "\\\\").replaceAll("\"", "\\\"");
}
function stripLore(lore) {
	return lore.replace(/["\\\n\r]/g, " ").replace(/\s+/g, " ").trim().slice(0, 280);
}
function renderSvg(spec) {
	const ink = inkById(spec.ink);
	const { cols, rows, lines } = measureAscii(spec.ascii);
	const cell = 10;
	const padX = 24;
	const padY = 28;
	const w = 48 + cols * cell * .62;
	const h = 56 + rows * cell;
	const texts = lines.map((line, i) => {
		const y = padY + cell * (i + .85);
		return `<text x="${padX}" y="${y}">${escapeXml(line)}</text>`;
	}).join("");
	return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w.toFixed(1)} ${h.toFixed(1)}" width="100%" height="100%" role="img">
<rect width="100%" height="100%" fill="${ink.bg}"/>
<style>text{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:${cell}px;fill:${ink.fg};white-space:pre}</style>
${texts}
</svg>`;
}
function generateSolidity(spec) {
	const { cols, rows } = measureAscii(spec.ascii);
	const artLines = padAscii(spec.ascii, cols, rows, " ").split("\n");
	const contractName = sanitizeIdentifier(`Glyphon_${spec.symbol}`, "GlyphonNFT");
	const name = escapeSolidity(spec.title.slice(0, 48) || "Glyphon");
	const symbol = sanitizeSymbol(spec.symbol);
	const lore = escapeSolidity(stripLore(spec.lore) || "Fully on-chain glyph.");
	const ink = inkById(spec.ink);
	return `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC721} from "@openzeppelin/contracts@5.0.2/token/ERC721/ERC721.sol";
import {Ownable} from "@openzeppelin/contracts@5.0.2/access/Ownable.sol";
import {Base64} from "@openzeppelin/contracts@5.0.2/utils/Base64.sol";
import {Strings} from "@openzeppelin/contracts@5.0.2/utils/Strings.sol";

/// @title ${contractName}
/// @notice Fully on-chain NFT. The token image is the ART constant below —
///         characters (1/0, #, *) stored in this contract. No IPFS.
/// @dev Paste into Remix, compile with 0.8.24, deploy. tokenURI returns SVG.
contract ${contractName} is ERC721, Ownable {
    using Strings for uint256;

    uint256 public constant MAX_SUPPLY = ${Math.max(1, Math.min(1e4, Math.floor(spec.maxSupply) || 1))};
    uint256 public constant COLS = ${cols};
    uint256 public constant ROWS = ${rows};
    uint256 public totalMinted;

    string public constant LORE = "${lore}";
    string public constant ENCODING = "${escapeSolidity(spec.paletteLabel)}";

    // The glyph. Adjacent string literals concatenate; this IS the image.
    string private constant ART =
${artLines.map((line) => `        "${escapeSolidity(line)}"`).join("\n")};

    constructor() ERC721("${name}", "${symbol}") Ownable(msg.sender) {}

    function mint(address to) external {
        require(totalMinted < MAX_SUPPLY, "sold out");
        totalMinted += 1;
        _safeMint(to, totalMinted);
    }

    function art() external pure returns (string memory) {
        return ART;
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        string memory svg = _svg();
        string memory json = string.concat(
            '{"name":"${name} #',
            tokenId.toString(),
            '","description":"',
            LORE,
            '","image":"data:image/svg+xml;base64,',
            Base64.encode(bytes(svg)),
            '","attributes":[{"trait_type":"Encoding","value":"',
            ENCODING,
            '"},{"trait_type":"Columns","value":"',
            COLS.toString(),
            '"},{"trait_type":"Rows","value":"',
            ROWS.toString(),
            '"}]}'
        );
        return string.concat("data:application/json;base64,", Base64.encode(bytes(json)));
    }

    function _svg() internal pure returns (string memory) {
        uint256 cell = 10;
        uint256 padX = 24;
        uint256 padY = 28;
        uint256 w = padX * 2 + (COLS * cell * 62) / 100;
        uint256 h = padY * 2 + ROWS * cell;
        bytes memory body;
        bytes memory artBytes = bytes(ART);
        for (uint256 y; y < ROWS; y++) {
            uint256 ty = padY + cell * (y + 1) - 2;
            body = abi.encodePacked(
                body,
                "<text x='",
                padX.toString(),
                "' y='",
                ty.toString(),
                "'>",
                _line(artBytes, y),
                "</text>"
            );
        }
        return string(
            abi.encodePacked(
                "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ",
                w.toString(),
                " ",
                h.toString(),
                "' width='100%' height='100%'>",
                "<rect width='100%' height='100%' fill='${ink.bg}'/>",
                "<style>text{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;fill:${ink.fg};white-space:pre}</style>",
                body,
                "</svg>"
            )
        );
    }

    function _line(bytes memory artBytes, uint256 y) internal pure returns (bytes memory) {
        bytes memory line = new bytes(COLS);
        uint256 start = y * COLS;
        for (uint256 i; i < COLS; i++) {
            line[i] = artBytes[start + i];
        }
        return line;
    }
}
`;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var inscribeGlyph = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Invalid input");
	if (typeof input.imageDataUrl !== "string" || input.imageDataUrl.length < 32) throw new Error("Image is required");
	if (input.imageDataUrl.length > 45e4) throw new Error("Image is too large");
	if (!input.imageDataUrl.startsWith("data:image/")) throw new Error("Image must be a data URL");
	const cols = Math.max(16, Math.min(64, Math.floor(input.cols) || 48));
	const rows = Math.max(8, Math.min(64, Math.floor(input.rows) || 28));
	const charset = (input.charset || "10").slice(0, 32);
	const draftAscii = (input.draftAscii || "").slice(0, 8e3);
	return {
		...input,
		cols,
		rows,
		charset,
		draftAscii
	};
}).handler(createSsrRpc("7e54931a3053a7758f305564507f59921d28a373a7e09691c2642408a8f4caf4"));
var KEY = "glyphon:inscriptions";
function loadGallery() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 24) : [];
	} catch {
		return [];
	}
}
function saveGlyph(entry) {
	const next = [entry, ...loadGallery().filter((g) => g.id !== entry.id)].slice(0, 24);
	localStorage.setItem(KEY, JSON.stringify(next));
	return next;
}
function removeGlyph(id) {
	const next = loadGallery().filter((g) => g.id !== id);
	localStorage.setItem(KEY, JSON.stringify(next));
	return next;
}
var SAMPLES = [
	{
		id: "bust",
		label: "Bust",
		src: "/samples/bust.jpg",
		title: "Marble Witness",
		symbol: "WITNS"
	},
	{
		id: "cat",
		label: "Cat",
		src: "/samples/cat.jpg",
		title: "Night Watch",
		symbol: "WATCH"
	},
	{
		id: "moon",
		label: "Moon",
		src: "/samples/moon.jpg",
		title: "Quiet Satellite",
		symbol: "LUNA"
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function downloadText(filename, contents) {
	const blob = new Blob([contents], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function copyText(text) {
	return navigator.clipboard.writeText(text);
}
function Badge({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full bg-raised px-2.5 py-1 text-micro font-medium tracking-wide text-muted", className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-raised text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-raised",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-raised",
			destructive: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5 text-sm",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-raised px-3 text-sm text-fg shadow-[var(--shadow-border)]", "placeholder:text-faint", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-muted", className),
		...props
	});
}
function ScrollArea({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
		className: cn("relative overflow-hidden", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scrollbar, {
			orientation: "vertical",
			className: "flex w-2 touch-none p-px",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { className: "relative flex-1 rounded-full bg-border" })
		})]
	});
}
function Separator({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-px w-full bg-border", className),
		role: "separator"
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1 w-full grow overflow-hidden rounded-full bg-raised",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-fg shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50" })]
	});
}
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-11 items-center gap-1 rounded-lg bg-raised p-1", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-xs font-medium text-muted", "transition-colors duration-[var(--motion-quick)]", "data-[state=active]:bg-surface data-[state=active]:text-fg", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("outline-none", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-20 w-full rounded-md bg-raised px-3 py-2 text-sm text-fg shadow-[var(--shadow-border)]", "placeholder:text-faint", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Studio() {
	const fileRef = (0, import_react.useRef)(null);
	const [source, setSource] = (0, import_react.useState)(null);
	const [paletteId, setPaletteId] = (0, import_react.useState)("binary");
	const [cols, setCols] = (0, import_react.useState)(48);
	const [invert, setInvert] = (0, import_react.useState)(false);
	const [dither, setDither] = (0, import_react.useState)(true);
	const [ascii, setAscii] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("Marble Witness");
	const [symbol, setSymbol] = (0, import_react.useState)("WITNS");
	const [lore, setLore] = (0, import_react.useState)("A photograph written into the contract as characters. Fully on-chain; no IPFS.");
	const [ink, setInk] = (0, import_react.useState)("bone");
	const [maxSupply, setMaxSupply] = (0, import_react.useState)(100);
	const [encoding, setEncoding] = (0, import_react.useState)("pixel");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [inscribing, setInscribing] = (0, import_react.useState)(false);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [gallery, setGallery] = (0, import_react.useState)([]);
	const [view, setView] = (0, import_react.useState)("glyph");
	const encodeGen = (0, import_react.useRef)(0);
	const palette = PALETTES.find((p) => p.id === paletteId) ?? PALETTES[0];
	const charset = sanitizeCharset(palette.chars);
	(0, import_react.useEffect)(() => {
		setGallery(loadGallery());
	}, []);
	(0, import_react.useEffect)(() => {
		applySource(SAMPLES[0].src, SAMPLES[0].title, SAMPLES[0].title, SAMPLES[0].symbol);
	}, []);
	const applySource = (0, import_react.useCallback)(async (src, label, nextTitle, nextSymbol) => {
		setBusy(true);
		try {
			const img = await loadImage(src);
			setSource({
				src,
				width: img.naturalWidth,
				height: img.naturalHeight,
				label
			});
			if (nextTitle) setTitle(nextTitle);
			if (nextSymbol) setSymbol(nextSymbol);
			setEncoding("pixel");
		} catch {
			toast.error("Could not read that image");
		} finally {
			setBusy(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!source) return;
		const gen = ++encodeGen.current;
		let cancelled = false;
		(async () => {
			try {
				const img = await loadImage(source.src);
				if (cancelled || gen !== encodeGen.current) return;
				const next = imageDataToAscii(rasterize(img, img.naturalWidth, img.naturalHeight, cols), {
					charset,
					invert,
					dither
				});
				if (cancelled || gen !== encodeGen.current) return;
				setAscii(next);
				setEncoding("pixel");
			} catch {
				if (!cancelled) toast.error("Encoding failed");
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [
		source,
		cols,
		charset,
		invert,
		dither
	]);
	const spec = (0, import_react.useMemo)(() => {
		const { cols: c, rows } = measureAscii(ascii || "10\n01");
		return {
			title: title.trim() || "Glyphon",
			symbol: sanitizeSymbol(symbol),
			lore: lore.trim(),
			ascii: padAscii(ascii || "10\n01", c || 2, rows || 2, charset[0] ?? " "),
			paletteLabel: palette.label,
			ink,
			maxSupply
		};
	}, [
		ascii,
		title,
		symbol,
		lore,
		palette.label,
		ink,
		maxSupply,
		charset
	]);
	const solidity = (0, import_react.useMemo)(() => generateSolidity(spec), [spec]);
	const svg = (0, import_react.useMemo)(() => renderSvg(spec), [spec]);
	const { cols: artCols, rows: artRows } = measureAscii(spec.ascii);
	const bytes = new TextEncoder().encode(spec.ascii).length;
	const onFiles = (files) => {
		const file = files?.[0];
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			toast.error("Drop a PNG, JPG, or WEBP");
			return;
		}
		const reader = new FileReader();
		reader.onload = () => {
			const result = String(reader.result ?? "");
			applySource(result, file.name.replace(/\.[^.]+$/, ""));
			setTitle(file.name.replace(/\.[^.]+$/, "") || "Custom Glyph");
			setSymbol("GLYPH");
		};
		reader.readAsDataURL(file);
	};
	const runInscribe = async () => {
		if (!source || !ascii) return;
		setInscribing(true);
		try {
			const img = await loadImage(source.src);
			const imageDataUrl = compressImage(img, img.naturalWidth, img.naturalHeight);
			const rows = rowsFor(cols, img.naturalWidth, img.naturalHeight);
			const result = await inscribeGlyph({ data: {
				imageDataUrl,
				charset,
				cols,
				rows,
				draftAscii: ascii
			} });
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			const padded = padAscii(result.ascii, cols, rows, charset[0] ?? " ");
			setAscii(padded);
			setTitle(result.title);
			setSymbol(result.symbol);
			setLore(result.lore);
			setEncoding("ai");
			toast.success("Image inscribed as characters");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Inscription failed");
		} finally {
			setInscribing(false);
		}
	};
	const persist = () => {
		const next = saveGlyph({
			id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
			title: spec.title,
			symbol: spec.symbol,
			lore: spec.lore,
			ascii: spec.ascii,
			paletteId,
			ink,
			svg,
			solidity,
			createdAt: Date.now()
		});
		setGallery(next);
		toast.success("Saved in this browser");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 pb-20 pt-6 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-micro font-medium tracking-label text-muted uppercase",
							children: "On-chain inscription"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-2 text-hero leading-hero font-medium tracking-display text-fg",
							children: "GLYPHON"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-sm leading-relaxed text-muted",
							children: "Upload a photograph. Encode it as 1s, 0s, hashes, and stars. The characters are written into a custom ERC-721 — the source is the art."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "ERC-721" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "No IPFS" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "SVG on-chain" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "rise-in rise-in-2 grid gap-3 sm:grid-cols-3",
				children: [
					{
						n: "01",
						t: "Image",
						d: "Drop a photo or pick a sample."
					},
					{
						n: "02",
						t: "Encode",
						d: "Map luminance to 1/0, #, * — or let Grok inscribe it."
					},
					{
						n: "03",
						t: "Contract",
						d: "Copy a Remix-ready Solidity file with the glyph inside."
					}
				].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-micro text-faint",
							children: step.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-medium text-fg",
							children: step.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted",
							children: step.d
						})
					]
				}, step.n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise-in rise-in-3 grid gap-4 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.18fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-4 rounded-2xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "image/png,image/jpeg,image/webp,image/gif",
							className: "hidden",
							tabIndex: -1,
							"aria-hidden": "true",
							onChange: (e) => onFiles(e.target.files)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => fileRef.current?.click(),
							onDragOver: (e) => {
								e.preventDefault();
								setDragging(true);
							},
							onDragLeave: () => setDragging(false),
							onDrop: (e) => {
								e.preventDefault();
								setDragging(false);
								onFiles(e.dataTransfer.files);
							},
							className: cn("relative flex min-h-44 flex-col items-center justify-center overflow-hidden rounded-lg bg-raised text-center", "shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)]", dragging && "shadow-[var(--shadow-border-hover)]"),
							children: [source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: source.src,
								alt: source.label,
								className: "absolute inset-0 size-full object-cover opacity-80 outline outline-1 -outline-offset-1 outline-white/10"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 text-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 text-sm text-fg",
									children: "Drop a photograph"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 text-xs text-muted",
									children: "PNG, JPG, or WEBP"
								})
							] }), source && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute inset-x-0 bottom-0 bg-bg/70 px-3 py-2 text-left text-micro text-fg backdrop-blur-sm",
								children: "Replace image"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Samples" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-3 gap-2",
							children: SAMPLES.map((sample) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void applySource(sample.src, sample.title, sample.title, sample.symbol),
								className: "group overflow-hidden rounded-lg bg-raised shadow-[var(--shadow-border)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: sample.src,
									alt: sample.label,
									className: "aspect-square w-full object-cover outline outline-1 -outline-offset-1 outline-white/10 transition-opacity duration-[var(--motion-quick)] group-hover:opacity-90"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block px-2 py-1.5 text-left text-micro text-muted",
									children: sample.label
								})]
							}, sample.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Character set" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3",
								children: PALETTES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPaletteId(p.id),
									className: cn("flex h-11 min-w-0 flex-col items-start justify-center rounded-md px-3 text-left transition-colors duration-[var(--motion-quick)]", paletteId === p.id ? "bg-accent text-accent-fg" : "bg-raised text-muted hover:text-fg"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium",
										children: p.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono max-w-full truncate text-xs tracking-normal opacity-70",
										children: p.chars.trim() || "·"
									})]
								}, p.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-micro text-faint",
								children: palette.hint
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cols",
								children: "Width"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular-nums text-muted",
								children: [cols, " ch"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							id: "cols",
							min: 24,
							max: 72,
							step: 1,
							value: [cols],
							onValueChange: (v) => setCols(v[0] ?? 48)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								active: invert,
								onClick: () => setInvert((v) => !v),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contrast, { className: "size-3.5" }),
								label: "Invert"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								active: dither,
								onClick: () => setDither((v) => !v),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Binary, { className: "size-3.5" }),
								label: "Dither"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Ink" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: INKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setInk(item.id),
								className: cn("h-11 rounded-md px-3 text-xs font-medium", ink === item.id ? "bg-accent text-accent-fg" : "bg-raised text-muted"),
								children: item.label
							}, item.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							onClick: () => void runInscribe(),
							disabled: !source || inscribing || busy,
							className: "w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wand, {}), inscribing ? "Inscribing…" : "Inscribe with Grok"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-micro leading-relaxed text-faint",
							children: "Grok looks at your photo and writes it as a character field using the set you picked, then names the collection."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-[28rem] min-w-0 flex-col rounded-2xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { className: "size-3.5 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted",
								children: encoding === "ai" ? "AI inscription" : "Pixel encode"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-micro tabular-nums text-faint",
							children: [
								artCols,
								"×",
								artRows,
								" · ",
								bytes,
								" bytes"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative flex min-h-72 flex-1 items-center justify-center overflow-hidden rounded-lg p-3 sm:p-5",
						style: { background: INKS.find((i) => i.id === ink)?.bg },
						children: busy && !ascii ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Encoding…"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "glyph-pre mx-auto w-max max-w-full overflow-x-auto text-left",
							style: {
								color: INKS.find((i) => i.id === ink)?.fg,
								fontSize: `clamp(4px, calc(min(86vw, 560px) / ${Math.max(artCols, 24)}), 11px)`
							},
							children: spec.ascii
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise-in rise-in-4 grid gap-4 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-4 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Collection name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: title,
									onChange: (e) => setTitle(e.target.value),
									maxLength: 48
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Symbol",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: symbol,
									onChange: (e) => setSymbol(e.target.value.toUpperCase()),
									maxLength: 8,
									className: "font-mono tracking-widest"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Lore",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: lore,
								onChange: (e) => setLore(e.target.value),
								maxLength: 280,
								rows: 3
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Max supply · ${maxSupply}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 1,
								max: 1e3,
								step: 1,
								value: [maxSupply],
								onValueChange: (v) => setMaxSupply(v[0] ?? 100)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "overflow-hidden rounded-xl",
							style: { background: INKS.find((i) => i.id === ink)?.bg },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between px-4 pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-micro tracking-wide text-muted uppercase",
									children: "Token preview"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-micro text-muted",
									children: [spec.symbol, " #1"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "aspect-square w-full",
								dangerouslySetInnerHTML: { __html: svg }
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-[24rem] min-w-0 flex-col rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
							value: view,
							onValueChange: setView,
							className: "flex min-h-0 flex-1 flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "glyph",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "mr-1.5 size-3.5" }), "Solidity"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "svg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "mr-1.5 size-3.5" }), "SVG"]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "secondary",
											size: "sm",
											onClick: () => {
												copyText(view === "svg" ? svg : solidity).then(() => toast.success("Copied"));
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "secondary",
											size: "sm",
											onClick: () => downloadText(view === "svg" ? `${spec.symbol.toLowerCase()}.svg` : `${spec.symbol}.sol`, view === "svg" ? svg : solidity),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
									value: "glyph",
									className: "mt-3 min-h-0 flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
										className: "h-96 min-w-0 w-full overflow-hidden rounded-xl bg-raised",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
											className: "glyph-pre overflow-x-auto p-4 text-xs leading-relaxed text-muted",
											children: solidity
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
									value: "svg",
									className: "mt-3 min-h-0 flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
										className: "h-96 min-w-0 w-full overflow-hidden rounded-xl bg-raised",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
											className: "glyph-pre overflow-x-auto p-4 text-xs leading-relaxed text-muted",
											children: svg
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: persist,
								className: "flex-1 sm:flex-none",
								children: "Save locally"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1 sm:flex-none",
								onClick: () => {
									copyText(solidity).then(() => toast.success("Contract copied — paste into Remix"));
								},
								children: "Copy for Remix"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-micro leading-relaxed text-faint",
							children: "Remix: compiler 0.8.24, OpenZeppelin 5 via the GitHub imports. The ART constant is the image — mint from any address until max supply."
						})
					]
				})]
			}),
			gallery.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Saved glyphs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Stored in this browser"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: gallery.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "block w-full",
						onClick: () => {
							setAscii(item.ascii);
							setTitle(item.title);
							setSymbol(item.symbol);
							setLore(item.lore);
							setPaletteId(item.paletteId);
							setInk(item.ink || "bone");
							setEncoding("pixel");
							toast.success("Loaded into the studio");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-square",
							dangerouslySetInnerHTML: { __html: item.svg }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-3 py-2 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-fg",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-micro text-muted",
								children: item.symbol
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "w-full border-t border-border px-3 py-2 text-left text-micro text-muted hover:text-fg",
						onClick: () => setGallery(removeGlyph(item.id)),
						children: "Remove"
					})]
				}, item.id))
			})] })
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function Toggle({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-md text-xs font-medium", active ? "bg-accent text-accent-fg" : "bg-raised text-muted"),
		children: [icon, label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-svh overflow-x-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "mx-auto max-w-6xl px-4 pb-10 pt-4 text-micro text-faint sm:px-6 lg:px-8",
			children: "Contracts are generated in the browser. Deploy from Remix or Foundry at your own risk — review the source before you mint."
		})]
	});
}
//#endregion
export { Home as component };
