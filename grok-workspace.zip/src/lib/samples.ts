export const SAMPLES = [
  {
    id: "bust",
    label: "Bust",
    src: "/samples/bust.jpg",
    title: "Marble Witness",
    symbol: "WITNS",
  },
  {
    id: "cat",
    label: "Cat",
    src: "/samples/cat.jpg",
    title: "Night Watch",
    symbol: "WATCH",
  },
  {
    id: "moon",
    label: "Moon",
    src: "/samples/moon.jpg",
    title: "Quiet Satellite",
    symbol: "LUNA",
  },
] as const;
