export type Palette = {
  id: string;
  label: string;
  chars: string;
  hint: string;
};

export const PALETTES: Palette[] = [
  {
    id: "binary",
    label: "Binary",
    chars: "10",
    hint: "Ones and zeros",
  },
  {
    id: "hash",
    label: "Hash",
    chars: " *#",
    hint: "Space, star, hash",
  },
  {
    id: "marks",
    label: "Marks",
    chars: " #",
    hint: "Silhouette in hashes",
  },
  {
    id: "stars",
    label: "Stars",
    chars: " *",
    hint: "Silhouette in stars",
  },
  {
    id: "blocks",
    label: "Blocks",
    chars: " ░▒▓█",
    hint: "Shaded box drawing",
  },
  {
    id: "classic",
    label: "Classic",
    chars: " .:-=+*#%@",
    hint: "Traditional ASCII",
  },
];

export const CHAR_ASPECT = 0.55;

export type EncodeOptions = {
  cols: number;
  invert: boolean;
  dither: boolean;
  charset: string;
};

function luma(r: number, g: number, b: number, a: number) {
  if (a < 8) return 0;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function rowsFor(cols: number, width: number, height: number) {
  const rows = Math.round(cols * (height / Math.max(width, 1)) * CHAR_ASPECT);
  return Math.max(8, Math.min(64, rows));
}

export function rasterize(
  source: CanvasImageSource,
  sourceWidth: number,
  sourceHeight: number,
  cols: number,
): ImageData {
  const rows = rowsFor(cols, sourceWidth, sourceHeight);
  const canvas = document.createElement("canvas");
  canvas.width = cols;
  canvas.height = rows;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas is unavailable");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, cols, rows);
  ctx.drawImage(source, 0, 0, cols, rows);
  return ctx.getImageData(0, 0, cols, rows);
}

export function imageDataToAscii(
  image: ImageData,
  options: Pick<EncodeOptions, "charset" | "invert" | "dither">,
): string {
  const { width, height, data } = image;
  const chars = Array.from(options.charset);
  if (chars.length < 2) {
    throw new Error("Charset needs at least two characters");
  }
  const n = chars.length - 1;
  const gray = new Float32Array(width * height);

  for (let i = 0; i < width * height; i++) {
    const o = i * 4;
    let v = luma(data[o]!, data[o + 1]!, data[o + 2]!, data[o + 3]!);
    if (options.invert) v = 255 - v;
    gray[i] = v;
  }

  const lines: string[] = [];
  for (let y = 0; y < height; y++) {
    let line = "";
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      let v = gray[i]!;
      if (v < 0) v = 0;
      if (v > 255) v = 255;
      const idx = Math.round((v / 255) * n);
      line += chars[idx];
      if (options.dither) {
        const quantized = (idx / n) * 255;
        const err = v - quantized;
        if (x + 1 < width) gray[i + 1]! += (err * 7) / 16;
        if (y + 1 < height) {
          if (x > 0) gray[i + width - 1]! += (err * 3) / 16;
          gray[i + width]! += (err * 5) / 16;
          if (x + 1 < width) gray[i + width + 1]! += (err * 1) / 16;
        }
      }
    }
    lines.push(line);
  }
  return lines.join("\n");
}

export function padAscii(ascii: string, cols: number, rows: number, fill = " ") {
  const src = ascii.replace(/\r/g, "").split("\n");
  const out: string[] = [];
  for (let y = 0; y < rows; y++) {
    const raw = src[y] ?? "";
    const clipped = Array.from(raw).slice(0, cols);
    while (clipped.length < cols) clipped.push(fill);
    out.push(clipped.join(""));
  }
  return out.join("\n");
}

export function measureAscii(ascii: string) {
  const lines = ascii.replace(/\r/g, "").split("\n").filter((l, i, a) => !(i === a.length - 1 && l === ""));
  const cols = lines.reduce((m, l) => Math.max(m, Array.from(l).length), 0);
  return { cols, rows: lines.length, lines };
}

export function sanitizeCharset(chars: string) {
  const forbidden = new Set(['"', "'", "\\", "<", ">", "&", "`"]);
  const seen = new Set<string>();
  let out = "";
  for (const ch of Array.from(chars)) {
    if (forbidden.has(ch) || seen.has(ch)) continue;
    if (ch.charCodeAt(0) < 32) continue;
    seen.add(ch);
    out += ch;
  }
  return out.length >= 2 ? out : "10";
}

export function compressImage(
  source: CanvasImageSource,
  width: number,
  height: number,
  maxEdge = 512,
  quality = 0.72,
): string {
  const scale = Math.min(1, maxEdge / Math.max(width, height));
  const w = Math.max(32, Math.round(width * scale));
  const h = Math.max(32, Math.round(height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is unavailable");
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(source, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", quality);
}

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read that image"));
    img.src = src;
  });
}
