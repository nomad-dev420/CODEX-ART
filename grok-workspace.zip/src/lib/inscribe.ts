import { createServerFn } from "@tanstack/react-start";

export type InscribeInput = {
  imageDataUrl: string;
  charset: string;
  cols: number;
  rows: number;
  draftAscii: string;
};

export type InscribeResult =
  | {
      ok: true;
      title: string;
      symbol: string;
      lore: string;
      ascii: string;
    }
  | { ok: false; error: string };

const SYSTEM = `You convert photographs into fully on-chain ASCII glyphs for NFT smart contracts.
Return a JSON object only, no markdown.
Fields:
- title: 2 to 4 words, museum-catalog tone, no quotes
- symbol: 3 to 5 uppercase letters, ticker-like
- lore: one sentence, no quotation marks, under 180 characters
- ascii: the image rewritten as a character field
ascii rules:
- exactly the requested number of lines
- every line exactly the requested width in characters
- use ONLY the provided charset characters
- darker regions use characters earlier in the charset, lighter regions use later ones
- capture the silhouette and major features; do not add a caption or border`;

export const inscribeGlyph = createServerFn({ method: "POST" })
  .validator((input: InscribeInput) => {
    if (!input || typeof input !== "object") {
      throw new Error("Invalid input");
    }
    if (typeof input.imageDataUrl !== "string" || input.imageDataUrl.length < 32) {
      throw new Error("Image is required");
    }
    if (input.imageDataUrl.length > 450_000) {
      throw new Error("Image is too large");
    }
    if (!input.imageDataUrl.startsWith("data:image/")) {
      throw new Error("Image must be a data URL");
    }
    const cols = Math.max(16, Math.min(64, Math.floor(input.cols) || 48));
    const rows = Math.max(8, Math.min(64, Math.floor(input.rows) || 28));
    const charset = (input.charset || "10").slice(0, 32);
    const draftAscii = (input.draftAscii || "").slice(0, 8_000);
    return { ...input, cols, rows, charset, draftAscii };
  })
  .handler(async ({ data }): Promise<InscribeResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false, error: "AI inscription is unavailable in this environment" };
    }

    const prompt = `Charset (dark → light): ${JSON.stringify(data.charset)}
Width (characters per line): ${data.cols}
Height (number of lines): ${data.rows}

A luminance draft of the same image (may be imperfect):
${data.draftAscii}

Rewrite the uploaded image as ascii using ONLY the charset. Match width and height exactly.`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.4,
        max_tokens: 2200,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: { url: data.imageDataUrl, detail: "high" },
              },
              { type: "text", text: prompt },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      return {
        ok: false,
        error: `Inscription failed (${res.status})${body ? `: ${body.slice(0, 180)}` : ""}`,
      };
    }

    const payload = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = payload.choices?.[0]?.message?.content ?? "";
    const parsed = parseInscribe(raw);
    if (!parsed) {
      return { ok: false, error: "The model returned an unreadable glyph" };
    }
    return { ok: true, ...parsed };
  });

function parseInscribe(raw: string) {
  const trimmed = raw.trim().replace(/^```json\s*/i, "").replace(/```$/i, "");
  try {
    const obj = JSON.parse(trimmed) as {
      title?: unknown;
      symbol?: unknown;
      lore?: unknown;
      ascii?: unknown;
    };
    const title = String(obj.title ?? "").trim().slice(0, 64);
    const symbol = String(obj.symbol ?? "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 8);
    const lore = String(obj.lore ?? "")
      .replace(/["\n\r]/g, " ")
      .trim()
      .slice(0, 280);
    const ascii = String(obj.ascii ?? "").replace(/\r/g, "");
    if (!ascii.trim()) return null;
    return {
      title: title || "Onchain Glyph",
      symbol: symbol || "GLYPH",
      lore: lore || "A photograph written into contract source.",
      ascii,
    };
  } catch {
    return null;
  }
}
