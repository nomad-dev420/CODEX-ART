import { measureAscii, padAscii } from "./ascii";

export const INKS = [
  { id: "bone", label: "Bone", bg: "#0c0c0d", fg: "#e8e4d8" },
  { id: "steel", label: "Steel", bg: "#0e1216", fg: "#c5d0d8" },
  { id: "sage", label: "Sage", bg: "#0c100e", fg: "#c5d4c8" },
  { id: "print", label: "Print", bg: "#ece8de", fg: "#1a1916" },
] as const;

export type InkId = (typeof INKS)[number]["id"];

export type GlyphSpec = {
  title: string;
  symbol: string;
  lore: string;
  ascii: string;
  paletteLabel: string;
  ink: InkId;
  maxSupply: number;
};

export function inkById(id: InkId) {
  return INKS.find((i) => i.id === id) ?? INKS[0];
}

export function sanitizeIdentifier(raw: string, fallback: string) {
  const cleaned = raw.replace(/[^A-Za-z0-9_]/g, "");
  const start = cleaned.replace(/^[^A-Za-z_]+/, "");
  return start.slice(0, 24) || fallback;
}

export function sanitizeSymbol(raw: string) {
  const cleaned = raw.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  return cleaned || "GLYPH";
}

export function escapeXml(s: string) {
  const amp = "\u0026";
  return s
    .replaceAll("&", `${amp}amp;`)
    .replaceAll("<", `${amp}lt;`)
    .replaceAll(">", `${amp}gt;`)
    .replaceAll('"', `${amp}quot;`);
}

export function escapeSolidity(s: string) {
  return s.replaceAll("\\", "\\\\").replaceAll('"', '\\"');
}

function stripLore(lore: string) {
  return lore.replace(/["\\\n\r]/g, " ").replace(/\s+/g, " ").trim().slice(0, 280);
}

export function renderSvg(spec: GlyphSpec) {
  const ink = inkById(spec.ink);
  const { cols, rows, lines } = measureAscii(spec.ascii);
  const cell = 10;
  const padX = 24;
  const padY = 28;
  const w = padX * 2 + cols * cell * 0.62;
  const h = padY * 2 + rows * cell;
  const texts = lines
    .map((line, i) => {
      const y = padY + cell * (i + 0.85);
      return `<text x="${padX}" y="${y}">${escapeXml(line)}</text>`;
    })
    .join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w.toFixed(1)} ${h.toFixed(1)}" width="100%" height="100%" role="img">
<rect width="100%" height="100%" fill="${ink.bg}"/>
<style>text{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:${cell}px;fill:${ink.fg};white-space:pre}</style>
${texts}
</svg>`;
}

export function svgDataUrl(spec: GlyphSpec) {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(renderSvg(spec))}`;
}

export function generateSolidity(spec: GlyphSpec) {
  const { cols, rows } = measureAscii(spec.ascii);
  const art = padAscii(spec.ascii, cols, rows, " ");
  const artLines = art.split("\n");
  const contractName = sanitizeIdentifier(
    `Glyphon_${spec.symbol}`,
    "GlyphonNFT",
  );
  const name = escapeSolidity(spec.title.slice(0, 48) || "Glyphon");
  const symbol = sanitizeSymbol(spec.symbol);
  const lore = escapeSolidity(stripLore(spec.lore) || "Fully on-chain glyph.");
  const ink = inkById(spec.ink);
  const supply = Math.max(1, Math.min(10000, Math.floor(spec.maxSupply) || 1));
  const encoding = escapeSolidity(spec.paletteLabel);

  const picture = artLines
    .map((line) => `        "${escapeSolidity(line)}"`)
    .join("\n");

  return `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC721} from "@openzeppelin/contracts@5.0.2/token/ERC721/ERC721.sol";
import {Ownable} from "@openzeppelin/contracts@5.0.2/access/Ownable.sol";
import {Base64} from "@openzeppelin/contracts@5.0.2/utils/Base64.sol";
import {Strings} from "@openzeppelin/contracts@5.0.2/utils/Strings.sol";

/// @title ${contractName}
/// @notice Fully on-chain NFT. The token image is the ART constant below —
///         characters (1/0, #, *) stored in this contract. No IPFS.
/// @dev Paste into Remix, compile with 0.8.24, deploy. tokenURI returns SVG.
contract ${contractName} is ERC721, Ownable {
    using Strings for uint256;

    uint256 public constant MAX_SUPPLY = ${supply};
    uint256 public constant COLS = ${cols};
    uint256 public constant ROWS = ${rows};
    uint256 public totalMinted;

    string public constant LORE = "${lore}";
    string public constant ENCODING = "${encoding}";

    // The glyph. Adjacent string literals concatenate; this IS the image.
    string private constant ART =
${picture};

    constructor() ERC721("${name}", "${symbol}") Ownable(msg.sender) {}

    function mint(address to) external {
        require(totalMinted < MAX_SUPPLY, "sold out");
        totalMinted += 1;
        _safeMint(to, totalMinted);
    }

    function art() external pure returns (string memory) {
        return ART;
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        string memory svg = _svg();
        string memory json = string.concat(
            '{"name":"${name} #',
            tokenId.toString(),
            '","description":"',
            LORE,
            '","image":"data:image/svg+xml;base64,',
            Base64.encode(bytes(svg)),
            '","attributes":[{"trait_type":"Encoding","value":"',
            ENCODING,
            '"},{"trait_type":"Columns","value":"',
            COLS.toString(),
            '"},{"trait_type":"Rows","value":"',
            ROWS.toString(),
            '"}]}'
        );
        return string.concat("data:application/json;base64,", Base64.encode(bytes(json)));
    }

    function _svg() internal pure returns (string memory) {
        uint256 cell = 10;
        uint256 padX = 24;
        uint256 padY = 28;
        uint256 w = padX * 2 + (COLS * cell * 62) / 100;
        uint256 h = padY * 2 + ROWS * cell;
        bytes memory body;
        bytes memory artBytes = bytes(ART);
        for (uint256 y; y < ROWS; y++) {
            uint256 ty = padY + cell * (y + 1) - 2;
            body = abi.encodePacked(
                body,
                "<text x='",
                padX.toString(),
                "' y='",
                ty.toString(),
                "'>",
                _line(artBytes, y),
                "</text>"
            );
        }
        return string(
            abi.encodePacked(
                "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ",
                w.toString(),
                " ",
                h.toString(),
                "' width='100%' height='100%'>",
                "<rect width='100%' height='100%' fill='${ink.bg}'/>",
                "<style>text{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;fill:${ink.fg};white-space:pre}</style>",
                body,
                "</svg>"
            )
        );
    }

    function _line(bytes memory artBytes, uint256 y) internal pure returns (bytes memory) {
        bytes memory line = new bytes(COLS);
        uint256 start = y * COLS;
        for (uint256 i; i < COLS; i++) {
            line[i] = artBytes[start + i];
        }
        return line;
    }
}
`;
}

export function defaultTitleFromPalette(paletteLabel: string) {
  return `${paletteLabel} Glyph`;
}
