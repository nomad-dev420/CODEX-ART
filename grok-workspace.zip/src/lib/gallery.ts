export type SavedGlyph = {
  id: string;
  title: string;
  symbol: string;
  lore: string;
  ascii: string;
  paletteId: string;
  ink: string;
  svg: string;
  solidity: string;
  createdAt: number;
};

const KEY = "glyphon:inscriptions";

export function loadGallery(): SavedGlyph[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedGlyph[];
    return Array.isArray(parsed) ? parsed.slice(0, 24) : [];
  } catch {
    return [];
  }
}

export function saveGlyph(entry: SavedGlyph) {
  const next = [entry, ...loadGallery().filter((g) => g.id !== entry.id)].slice(0, 24);
  localStorage.setItem(KEY, JSON.stringify(next));
  return next;
}

export function removeGlyph(id: string) {
  const next = loadGallery().filter((g) => g.id !== id);
  localStorage.setItem(KEY, JSON.stringify(next));
  return next;
}
