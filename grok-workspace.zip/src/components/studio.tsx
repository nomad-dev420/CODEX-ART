import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Binary,
  Contrast,
  Copy,
  Download,
  FileCode2,
  Hash,
  Image as ImageIcon,
  Upload,
  Wand,
} from "lucide-react";
import { toast } from "sonner";
import {
  PALETTES,
  compressImage,
  imageDataToAscii,
  loadImage,
  measureAscii,
  padAscii,
  rasterize,
  rowsFor,
  sanitizeCharset,
} from "@/lib/ascii";
import {
  INKS,
  type InkId,
  generateSolidity,
  renderSvg,
  sanitizeSymbol,
} from "@/lib/contract";
import { inscribeGlyph } from "@/lib/inscribe";
import {
  type SavedGlyph,
  loadGallery,
  removeGlyph,
  saveGlyph,
} from "@/lib/gallery";
import { SAMPLES } from "@/lib/samples";
import { copyText, cn, downloadText } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

type Source = {
  src: string;
  width: number;
  height: number;
  label: string;
};

export function Studio() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [source, setSource] = useState<Source | null>(null);
  const [paletteId, setPaletteId] = useState("binary");
  const [cols, setCols] = useState(48);
  const [invert, setInvert] = useState(false);
  const [dither, setDither] = useState(true);
  const [ascii, setAscii] = useState("");
  const [title, setTitle] = useState("Marble Witness");
  const [symbol, setSymbol] = useState("WITNS");
  const [lore, setLore] = useState(
    "A photograph written into the contract as characters. Fully on-chain; no IPFS.",
  );
  const [ink, setInk] = useState<InkId>("bone");
  const [maxSupply, setMaxSupply] = useState(100);
  const [encoding, setEncoding] = useState<"pixel" | "ai">("pixel");
  const [busy, setBusy] = useState(false);
  const [inscribing, setInscribing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [gallery, setGallery] = useState<SavedGlyph[]>([]);
  const [view, setView] = useState("glyph");
  const encodeGen = useRef(0);

  const palette = PALETTES.find((p) => p.id === paletteId) ?? PALETTES[0]!;
  const charset = sanitizeCharset(palette.chars);

  useEffect(() => {
    setGallery(loadGallery());
  }, []);

  useEffect(() => {
    void applySource(SAMPLES[0].src, SAMPLES[0].title, SAMPLES[0].title, SAMPLES[0].symbol);
    // First paint: load the bust so the stage is never empty.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const applySource = useCallback(
    async (src: string, label: string, nextTitle?: string, nextSymbol?: string) => {
      setBusy(true);
      try {
        const img = await loadImage(src);
        setSource({
          src,
          width: img.naturalWidth,
          height: img.naturalHeight,
          label,
        });
        if (nextTitle) setTitle(nextTitle);
        if (nextSymbol) setSymbol(nextSymbol);
        setEncoding("pixel");
      } catch {
        toast.error("Could not read that image");
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (!source) return;
    const gen = ++encodeGen.current;
    let cancelled = false;
    (async () => {
      try {
        const img = await loadImage(source.src);
        if (cancelled || gen !== encodeGen.current) return;
        const data = rasterize(img, img.naturalWidth, img.naturalHeight, cols);
        const next = imageDataToAscii(data, { charset, invert, dither });
        if (cancelled || gen !== encodeGen.current) return;
        setAscii(next);
        setEncoding("pixel");
      } catch {
        if (!cancelled) toast.error("Encoding failed");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [source, cols, charset, invert, dither]);

  const spec = useMemo(() => {
    const { cols: c, rows } = measureAscii(ascii || "10\n01");
    return {
      title: title.trim() || "Glyphon",
      symbol: sanitizeSymbol(symbol),
      lore: lore.trim(),
      ascii: padAscii(ascii || "10\n01", c || 2, rows || 2, charset[0] ?? " "),
      paletteLabel: palette.label,
      ink,
      maxSupply,
    };
  }, [ascii, title, symbol, lore, palette.label, ink, maxSupply, charset]);

  const solidity = useMemo(() => generateSolidity(spec), [spec]);
  const svg = useMemo(() => renderSvg(spec), [spec]);
  const { cols: artCols, rows: artRows } = measureAscii(spec.ascii);
  const bytes = new TextEncoder().encode(spec.ascii).length;

  const onFiles = (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Drop a PNG, JPG, or WEBP");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      void applySource(result, file.name.replace(/\.[^.]+$/, ""));
      setTitle(file.name.replace(/\.[^.]+$/, "") || "Custom Glyph");
      setSymbol("GLYPH");
    };
    reader.readAsDataURL(file);
  };

  const runInscribe = async () => {
    if (!source || !ascii) return;
    setInscribing(true);
    try {
      const img = await loadImage(source.src);
      const imageDataUrl = compressImage(img, img.naturalWidth, img.naturalHeight);
      const rows = rowsFor(cols, img.naturalWidth, img.naturalHeight);
      const result = await inscribeGlyph({
        data: {
          imageDataUrl,
          charset,
          cols,
          rows,
          draftAscii: ascii,
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      const padded = padAscii(result.ascii, cols, rows, charset[0] ?? " ");
      setAscii(padded);
      setTitle(result.title);
      setSymbol(result.symbol);
      setLore(result.lore);
      setEncoding("ai");
      toast.success("Image inscribed as characters");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Inscription failed");
    } finally {
      setInscribing(false);
    }
  };

  const persist = () => {
    const id =
      typeof crypto !== "undefined" && crypto.randomUUID
        ? crypto.randomUUID()
        : String(Date.now());
    const next = saveGlyph({
      id,
      title: spec.title,
      symbol: spec.symbol,
      lore: spec.lore,
      ascii: spec.ascii,
      paletteId,
      ink,
      svg,
      solidity,
      createdAt: Date.now(),
    });
    setGallery(next);
    toast.success("Saved in this browser");
  };

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 pb-20 pt-6 sm:px-6 lg:px-8">
      <header className="rise-in flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div className="max-w-xl">
          <p className="text-micro font-medium tracking-label text-muted uppercase">
            On-chain inscription
          </p>
          <h1 className="font-display mt-2 text-hero leading-hero font-medium tracking-display text-fg">
            GLYPHON
          </h1>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
            Upload a photograph. Encode it as 1s, 0s, hashes, and stars. The
            characters are written into a custom ERC-721 — the source is the art.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge>ERC-721</Badge>
          <Badge>No IPFS</Badge>
          <Badge>SVG on-chain</Badge>
        </div>
      </header>

      <ol className="rise-in rise-in-2 grid gap-3 sm:grid-cols-3">
        {[
          { n: "01", t: "Image", d: "Drop a photo or pick a sample." },
          { n: "02", t: "Encode", d: "Map luminance to 1/0, #, * — or let Grok inscribe it." },
          { n: "03", t: "Contract", d: "Copy a Remix-ready Solidity file with the glyph inside." },
        ].map((step) => (
          <li
            key={step.n}
            className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]"
          >
            <p className="font-mono text-micro text-faint">{step.n}</p>
            <p className="mt-2 text-sm font-medium text-fg">{step.t}</p>
            <p className="mt-1 text-xs leading-relaxed text-muted">{step.d}</p>
          </li>
        ))}
      </ol>

      <div className="rise-in rise-in-3 grid gap-4 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.18fr)]">
        <section className="flex min-w-0 flex-col gap-4 rounded-2xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4">
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => onFiles(e.target.files)}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              onFiles(e.dataTransfer.files);
            }}
            className={cn(
              "relative flex min-h-44 flex-col items-center justify-center overflow-hidden rounded-lg bg-raised text-center",
              "shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)]",
              dragging && "shadow-[var(--shadow-border-hover)]",
            )}
          >
            {source ? (
              <img
                src={source.src}
                alt={source.label}
                className="absolute inset-0 size-full object-cover opacity-80 outline outline-1 -outline-offset-1 outline-white/10"
              />
            ) : (
              <>
                <Upload className="size-5 text-muted" />
                <span className="mt-2 text-sm text-fg">Drop a photograph</span>
                <span className="mt-1 text-xs text-muted">PNG, JPG, or WEBP</span>
              </>
            )}
            {source && (
              <span className="absolute inset-x-0 bottom-0 bg-bg/70 px-3 py-2 text-left text-micro text-fg backdrop-blur-sm">
                Replace image
              </span>
            )}
          </button>

          <div>
            <Label>Samples</Label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {SAMPLES.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() =>
                    void applySource(sample.src, sample.title, sample.title, sample.symbol)
                  }
                  className="group overflow-hidden rounded-lg bg-raised shadow-[var(--shadow-border)]"
                >
                  <img
                    src={sample.src}
                    alt={sample.label}
                    className="aspect-square w-full object-cover outline outline-1 -outline-offset-1 outline-white/10 transition-opacity duration-[var(--motion-quick)] group-hover:opacity-90"
                  />
                  <span className="block px-2 py-1.5 text-left text-micro text-muted">
                    {sample.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <Label>Character set</Label>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {PALETTES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPaletteId(p.id)}
                  className={cn(
                    "flex h-11 min-w-0 flex-col items-start justify-center rounded-md px-3 text-left transition-colors duration-[var(--motion-quick)]",
                    paletteId === p.id
                      ? "bg-accent text-accent-fg"
                      : "bg-raised text-muted hover:text-fg",
                  )}
                >
                  <span className="text-xs font-medium">{p.label}</span>
                  <span className="font-mono max-w-full truncate text-xs tracking-normal opacity-70">
                    {p.chars.trim() || "·"}
                  </span>
                </button>
              ))}
            </div>
            <p className="mt-2 text-micro text-faint">{palette.hint}</p>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <Label htmlFor="cols">Width</Label>
              <span className="font-mono text-xs tabular-nums text-muted">{cols} ch</span>
            </div>
            <Slider
              id="cols"
              min={24}
              max={72}
              step={1}
              value={[cols]}
              onValueChange={(v) => setCols(v[0] ?? 48)}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Toggle
              active={invert}
              onClick={() => setInvert((v) => !v)}
              icon={<Contrast className="size-3.5" />}
              label="Invert"
            />
            <Toggle
              active={dither}
              onClick={() => setDither((v) => !v)}
              icon={<Binary className="size-3.5" />}
              label="Dither"
            />
          </div>

          <div>
            <Label>Ink</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              {INKS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setInk(item.id)}
                  className={cn(
                    "h-11 rounded-md px-3 text-xs font-medium",
                    ink === item.id
                      ? "bg-accent text-accent-fg"
                      : "bg-raised text-muted",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <Button
            type="button"
            onClick={() => void runInscribe()}
            disabled={!source || inscribing || busy}
            className="w-full"
          >
            <Wand />
            {inscribing ? "Inscribing…" : "Inscribe with Grok"}
          </Button>
          <p className="text-micro leading-relaxed text-faint">
            Grok looks at your photo and writes it as a character field using the
            set you picked, then names the collection.
          </p>
        </section>

        <section className="flex min-h-[28rem] min-w-0 flex-col rounded-2xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Hash className="size-3.5 text-muted" />
              <p className="text-xs font-medium text-muted">
                {encoding === "ai" ? "AI inscription" : "Pixel encode"}
              </p>
            </div>
            <p className="font-mono text-micro tabular-nums text-faint">
              {artCols}×{artRows} · {bytes} bytes
            </p>
          </div>
          <div
            className="relative flex min-h-72 flex-1 items-center justify-center overflow-hidden rounded-lg p-3 sm:p-5"
            style={{ background: INKS.find((i) => i.id === ink)?.bg }}
          >
            {busy && !ascii ? (
              <p className="text-xs text-muted">Encoding…</p>
            ) : (
              <pre
                className="glyph-pre mx-auto w-max max-w-full overflow-x-auto text-left"
                style={{
                  color: INKS.find((i) => i.id === ink)?.fg,
                  fontSize: `clamp(4px, calc(min(86vw, 560px) / ${Math.max(artCols, 24)}), 11px)`,
                }}
              >
                {spec.ascii}
              </pre>
            )}
          </div>
        </section>
      </div>

      <div className="rise-in rise-in-4 grid gap-4 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
        <section className="flex min-w-0 flex-col gap-4 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Collection name">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={48} />
            </Field>
            <Field label="Symbol">
              <Input
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                maxLength={8}
                className="font-mono tracking-widest"
              />
            </Field>
          </div>
          <Field label="Lore">
            <Textarea
              value={lore}
              onChange={(e) => setLore(e.target.value)}
              maxLength={280}
              rows={3}
            />
          </Field>
          <Field label={`Max supply · ${maxSupply}`}>
            <Slider
              min={1}
              max={1000}
              step={1}
              value={[maxSupply]}
              onValueChange={(v) => setMaxSupply(v[0] ?? 100)}
            />
          </Field>
          <div
            className="overflow-hidden rounded-xl"
            style={{ background: INKS.find((i) => i.id === ink)?.bg }}
          >
            <div className="flex items-center justify-between px-4 pt-3">
              <p className="text-micro tracking-wide text-muted uppercase">Token preview</p>
              <p className="font-mono text-micro text-muted">
                {spec.symbol} #1
              </p>
            </div>
            <div
              className="aspect-square w-full"
              dangerouslySetInnerHTML={{ __html: svg }}
            />
          </div>
        </section>

        <section className="flex min-h-[24rem] min-w-0 flex-col rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <Tabs value={view} onValueChange={setView} className="flex min-h-0 flex-1 flex-col">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <TabsList>
                <TabsTrigger value="glyph">
                  <FileCode2 className="mr-1.5 size-3.5" />
                  Solidity
                </TabsTrigger>
                <TabsTrigger value="svg">
                  <ImageIcon className="mr-1.5 size-3.5" />
                  SVG
                </TabsTrigger>
              </TabsList>
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    void copyText(view === "svg" ? svg : solidity).then(() =>
                      toast.success("Copied"),
                    );
                  }}
                >
                  <Copy />
                  Copy
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() =>
                    downloadText(
                      view === "svg"
                        ? `${spec.symbol.toLowerCase()}.svg`
                        : `${spec.symbol}.sol`,
                      view === "svg" ? svg : solidity,
                    )
                  }
                >
                  <Download />
                  Download
                </Button>
              </div>
            </div>
            <TabsContent value="glyph" className="mt-3 min-h-0 flex-1">
              <ScrollArea className="h-96 min-w-0 w-full overflow-hidden rounded-xl bg-raised">
                <pre className="glyph-pre overflow-x-auto p-4 text-xs leading-relaxed text-muted">
                  {solidity}
                </pre>
              </ScrollArea>
            </TabsContent>
            <TabsContent value="svg" className="mt-3 min-h-0 flex-1">
              <ScrollArea className="h-96 min-w-0 w-full overflow-hidden rounded-xl bg-raised">
                <pre className="glyph-pre overflow-x-auto p-4 text-xs leading-relaxed text-muted">
                  {svg}
                </pre>
              </ScrollArea>
            </TabsContent>
          </Tabs>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button type="button" onClick={persist} className="flex-1 sm:flex-none">
              Save locally
            </Button>
            <Button
              type="button"
              variant="outline"
              className="flex-1 sm:flex-none"
              onClick={() => {
                void copyText(solidity).then(() =>
                  toast.success("Contract copied — paste into Remix"),
                );
              }}
            >
              Copy for Remix
            </Button>
          </div>
          <p className="mt-2 text-micro leading-relaxed text-faint">
            Remix: compiler 0.8.24, OpenZeppelin 5 via the GitHub imports. The
            ART constant is the image — mint from any address until max supply.
          </p>
        </section>
      </div>

      {gallery.length > 0 && (
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-xl font-medium tracking-tight">Saved glyphs</h2>
            <p className="text-xs text-muted">Stored in this browser</p>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {gallery.map((item) => (
              <article
                key={item.id}
                className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]"
              >
                <button
                  type="button"
                  className="block w-full"
                  onClick={() => {
                    setAscii(item.ascii);
                    setTitle(item.title);
                    setSymbol(item.symbol);
                    setLore(item.lore);
                    setPaletteId(item.paletteId);
                    setInk((item.ink as InkId) || "bone");
                    setEncoding("pixel");
                    toast.success("Loaded into the studio");
                  }}
                >
                  <div
                    className="aspect-square"
                    dangerouslySetInnerHTML={{ __html: item.svg }}
                  />
                  <div className="px-3 py-2 text-left">
                    <p className="truncate text-sm text-fg">{item.title}</p>
                    <p className="font-mono text-micro text-muted">{item.symbol}</p>
                  </div>
                </button>
                <button
                  type="button"
                  className="w-full border-t border-border px-3 py-2 text-left text-micro text-muted hover:text-fg"
                  onClick={() => setGallery(removeGlyph(item.id))}
                >
                  Remove
                </button>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Toggle({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-md text-xs font-medium",
        active ? "bg-accent text-accent-fg" : "bg-raised text-muted",
      )}
    >
      {icon}
      {label}
    </button>
  );
}
