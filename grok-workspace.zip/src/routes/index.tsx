import { createFileRoute } from "@tanstack/react-router";
import { Studio } from "@/components/studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="min-h-svh overflow-x-hidden bg-bg">
      <Studio />
      <footer className="mx-auto max-w-6xl px-4 pb-10 pt-4 text-micro text-faint sm:px-6 lg:px-8">
        Contracts are generated in the browser. Deploy from Remix or Foundry at
        your own risk — review the source before you mint.
      </footer>
    </main>
  );
}
